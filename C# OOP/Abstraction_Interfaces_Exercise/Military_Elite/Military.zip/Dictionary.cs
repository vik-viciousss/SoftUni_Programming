﻿namespace Military_Elite
{
    internal class Dictionary<T>
    {
    }
}