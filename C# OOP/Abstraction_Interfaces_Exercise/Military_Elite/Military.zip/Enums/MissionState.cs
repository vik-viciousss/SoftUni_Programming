﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Military_Elite.Enums
{
    public enum MissionState
    {
        inProgress,
        Finished
    }
}
