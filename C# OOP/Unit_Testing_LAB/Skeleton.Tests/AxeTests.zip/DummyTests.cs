﻿using NUnit.Framework;

[TestFixture]
public class DummyTests
{
    [Test]
    public void When_DummyIsAttacked_ShouldTakeDamage()
    {
        int health = 5;
        int experience = 5;
        int attackPoints = 3;
        Dummy dummy = new Dummy(health, experience);

        dummy.TakeAttack(attackPoints);

        Assert.AreEqual(dummy.Health, health - attackPoints);
    }
}
