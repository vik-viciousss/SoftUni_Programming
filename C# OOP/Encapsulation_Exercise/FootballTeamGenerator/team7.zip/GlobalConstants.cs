﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FootballTeamGenerator
{
    public class GlobalConstants
    {
        public const string InvalidNameExceptionErrorMessage = "A name should not be empty.";

    }
}
