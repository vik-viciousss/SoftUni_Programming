﻿using System;

namespace AuthorProblem
{
    public class StartUp
    {
        static void Main(string[] args)
        {
             


        }
    }
}
