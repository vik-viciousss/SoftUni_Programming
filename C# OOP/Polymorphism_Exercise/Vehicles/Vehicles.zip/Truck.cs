﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public class Truck : Vehicle
    {
        private const double consumptionIncrease = 1.6;

        public Truck(double fuelQuantity, double fuelConsumption) 
            : base(fuelQuantity)
        {
            this.FuelConsumptionInLitersPerKilometer = fuelConsumption + consumptionIncrease;
        }

        public override void Refuel(double fuel)
        {
            this.FuelQuantity += 0.95 * fuel;
        }
    }
}
