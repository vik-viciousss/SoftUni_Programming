﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public abstract class Vehicle
    {
        public Vehicle(double fuelQuantity)
        {
            this.FuelQuantity = fuelQuantity;
        }

        public double FuelQuantity { get; set; }

        public double FuelConsumptionInLitersPerKilometer { get; set; }

        public int Drive(double distance)
        {
            double fuelToConsume = distance * this.FuelConsumptionInLitersPerKilometer;

            if (this.FuelQuantity >= fuelToConsume)
            {
                this.FuelQuantity -= fuelToConsume;
                return 0;
            }

            return -1;
        }

        public abstract void Refuel(double fuel);

    }
}
