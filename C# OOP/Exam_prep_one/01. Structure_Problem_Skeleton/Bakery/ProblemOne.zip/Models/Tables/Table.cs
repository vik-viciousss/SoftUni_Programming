﻿using Bakery.Models.BakedFoods;
using Bakery.Models.BakedFoods.Contracts;
using Bakery.Models.Drinks;
using Bakery.Models.Drinks.Contracts;
using Bakery.Models.Tables.Contracts;
using Bakery.Utilities.Enums;
using Bakery.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Text;

namespace Bakery.Models.Tables
{
    public abstract class Table : ITable
    {
        private readonly List<BakedFood> FoodOrders;
        private readonly List<Drink> DrinkOrders;
        private int tableNumber;
        private int capacity;
        private int numberOfPeople;
        private decimal pricePerPerson;
        private bool isReserved;
        private decimal price;

        public Table(int tableNumber, int capacity, decimal pricePerPerson)
        {
            this.FoodOrders = new List<BakedFood>();
            this.DrinkOrders = new List<Drink>();
            this.TableNumber = tableNumber;
            this.Capacity = capacity;
            this.PricePerPerson = pricePerPerson;
            this.IsReserved = false;
        }

        public int TableNumber
        {
            get => this.tableNumber;
            private set
            {
                this.tableNumber = value;
            }
        }

        public int Capacity
        {
            get => this.capacity;
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException(ExceptionMessages.InvalidTableCapacity);
                }

                this.capacity = value;
            }
        }

        public int NumberOfPeople
        {
            get => this.numberOfPeople;
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentException(ExceptionMessages.InvalidNumberOfPeople);
                }

                this.numberOfPeople = value;
            }
        }

        public decimal PricePerPerson
        {
            get => this.pricePerPerson;
            private set => this.pricePerPerson = value;
        }

        public bool IsReserved
        {
            get => this.isReserved;
            set => this.isReserved = value;
        }

        public decimal Price
        {
            get => this.price;
            private set
            {
                this.price = this.pricePerPerson * this.numberOfPeople;
            }
        }

        public void Reserve(int numberOfPeople)
        {
            if (!IsReserved)
            {
                this.NumberOfPeople = numberOfPeople;
                IsReserved = true;
            }
        }

        public void OrderFood(IBakedFood food)
        {
            this.FoodOrders.Add((BakedFood)food);
        }

        public void OrderDrink(IDrink drink)
        {
            this.DrinkOrders.Add((Drink)drink);
        }

        public decimal GetBill()
        {
            decimal sum = 0;

            foreach (var drink in DrinkOrders)
            {
                sum += drink.Price;
            }

            foreach (var food in FoodOrders)
            {
                sum += food.Price;
            }

            return sum;
        }

        public void Clear()
        {
            this.FoodOrders.Clear();
            this.DrinkOrders.Clear();
            this.IsReserved = false;
            //
            this.NumberOfPeople = default;
        }

        public string GetFreeTableInfo()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Table: {this.TableNumber}");
            sb.AppendLine($"Type: {this.IsReserved}");
            sb.AppendLine($"Capacity: {this.Capacity}");
            sb.AppendLine($"Price per Person: {this.PricePerPerson}");

            return sb.ToString().TrimEnd();
        }


    }
}
