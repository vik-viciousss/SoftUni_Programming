﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Generic_Box_Of_String
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            List<Box<string>> boxes = new List<Box<string>>();

            for (int i = 0; i < n; i++)
            {
                string input = Console.ReadLine();

                Box<string> currBox = new Box<string>(input);

                boxes.Add(currBox);
            }

            int[] indexes = Console.ReadLine().Split().Select(int.Parse).ToArray();

            Swap(boxes, indexes[0], indexes[1]);

            foreach (var box in boxes)
            {
                Console.WriteLine(box);
            }
        }

        private static void Swap<T>(List<Box<T>> boxes, int indexOne, int indexTwo)
        {
            Box<T> temp = boxes[indexOne];
            boxes[indexOne] = boxes[indexTwo];
            boxes[indexTwo] = temp;
        }
    }
}
