﻿using System;

namespace Generic_Box_Of_String
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                int input = int.Parse(Console.ReadLine());

                Box<int> currBox = new Box<int>(input);

                Console.WriteLine(currBox);
            }
        }
    }
}
