﻿using System;
using System.Collections.Generic;

namespace IteratorsAndComparators
{
    public class Program
    {
        static void Main(string[] args)
        {
            //List<string> authors = new List<string>() { "John" };

            //List<Book> books = new List<Book>()
            //{
            //    new Book("Gone", 1879, authors),
            //    new Book("Not gone", 1879, authors)
            //};

            //Library<Book> myLibrary = new Library<Book>(books);

            //foreach (var book in myLibrary)
            //{
            //    Console.WriteLine(book.Title);
            //}


        }
    }
}
